var config = {
    port: "3306", // 連接阜號
    host: "127.0.0.1", // 主機名稱
    user: "root", // 用戶名稱 ( 請輸入root或是安裝時自行設定的帳號 )
    password: "admin", // 資料庫密碼 ( 請輸入admin或是安裝時自行設定的密碼 )
    database: "test", // 資料庫名稱
    connectionLimit: 10 //連線池限制
};

module.exports = config; //模組匯出