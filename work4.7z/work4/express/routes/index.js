const express = require('express');
const path = require('path');
const router = express.Router();
var mariadb = require("mariadb/callback");
var con = require("../config/DBconfig");
var multer = require('multer');
const app = express();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, '../server/img'));
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

router.get('/', (req, res) => {
  const filePath = path.join(__dirname, '../../web/test.html');
  res.sendFile(filePath);
  console.log(req.session)
});

const pool = mariadb.createPool({
  port: con.port,
  host: con.host,
  user: con.user,
  password: con.password,
  database: con.database,
  connectionLimit: con.connectionLimit,
});

router.get("/session_login", (req, res) => {
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("練線失敗! 因為錯誤：" + err);
    } else {
      const sql = 'SELECT session,permissions FROM user WHERE name = ?';
      const { user } = req.session;
      conn.query(sql, [user], (err, rows) => {
        conn.release();
        if (err) {
          console.error('資料庫查詢錯誤:', err);
          return;
        }
        let sever
        if (rows.length > 0) {
          sever = rows[0].session;
          permissions = rows[0].permissions;
        }
        const divite = req.cookies.user.split(".");//cookie
        const usercookie = divite[0].substr(2);//cookie
        if (sever == usercookie) {
          const a = "you login"
          data = { a, permissions };
          res.send(data);
        }
        else {
          res.send("you need login")
        }
      });
      conn.end()
    }
  });
});

router.get("/session_out", (req, res) => {
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("連接失敗！錯誤：" + err);
      res.status(500).json({ error: '數據庫連接失敗' });
      return;
    }
    const query = 'UPDATE user SET session = (?) WHERE name = (?)';
    const values = null
    const { user } = req.session;
    conn.query(query, [values, user], (err, result) => {
      conn.release();
      if (err) {
        console.error('插入數據時發生錯誤：', err);
        res.status(500).json({ error: '插入數據時發生錯誤' });
        return;
      }
      conn.end()
    });
  });
});




router.get("/product", (req, res) => {
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("練線失敗! 因為錯誤：" + err);
    } else {
      conn.query('SELECT * FROM product', (err, rows) => {
        conn.release();
        if (err) {
          console.error('資料庫查詢錯誤:', err);
          return;
        }
        res.json(rows);
      });
      console.log("成功連線! 連線 ID：" + conn.threadId);
      conn.end()
    }
  });
});

router.post("/user", express.json(), (req, res) => {
  const { name, password } = req.body;
  if (!name || !password) {
    res.status(400).json({ error: '缺少必要的數據' });
    return;
  }
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("連接失敗！錯誤：" + err);
      res.status(500).json({ error: '數據庫連接失敗' });
      return;
    }
    const query = 'INSERT INTO user (name, password) VALUES (?, ?)';
    const values = [name, password];
    conn.query(query, values, (err, result) => {
      conn.release();
      if (err) {
        console.error('插入數據時發生錯誤：', err);
        res.status(500).json({ error: '插入數據時發生錯誤' });
        return;
      }
      res.json({ message: '新增數據成功', insertId: result.insertId.toString() });
      conn.end()
    });
  });
});

router.get("/user/login", (req, res) => {
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("練線失敗! 因為錯誤：" + err);
    } else {
      conn.query('SELECT * FROM user', (err, rows) => {
        conn.release();
        if (err) {
          console.error('資料庫查詢錯誤:', err);
          return;
        }
        res.json(rows);
      });
      conn.end()
    }
  });
});

router.post("/user/login/cookie", (req, res) => {
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("連接失敗！錯誤：" + err);
      res.status(500).json({ error: '數據庫連接失敗' });
      return;
    }
    const query = 'UPDATE user SET session = (?) WHERE name = (?)';
    const values = req.sessionID;
    const { name } = req.body;
    req.session.user = name;
    const { user } = req.session;
    req.session.save()
    conn.query(query, [values, user], (err, result) => {
      conn.end();
      if (err) {
        console.error('插入數據時發生錯誤：', err);
        res.status(500).json({ error: '插入數據時發生錯誤' });
        return;
      }
      conn.end()
    });
  });
});

router.post("/product/post", express.json(), (req, res) => {
  const { name, picture, pric, number } = req.body;
  if (!name || !picture || !pric || !number) {
    res.status(400).json({ error: '缺少必要的數據' });
    return;
  }
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("連接失敗！錯誤：" + err);
      res.status(500).json({ error: '數據庫連接失敗' });
      return;
    }
    const query = 'INSERT INTO product (name,picture,pric,number) VALUES ( ?, ?, ?, ?)';
    const values = [name, picture, pric, number];
    conn.query(query, values, (err, result) => {
      conn.release();
      if (err) {
        console.error('插入數據時發生錯誤：', err);
        res.status(500).json({ error: '插入數據時發生錯誤' });
        return;
      }
      res.send("success")
      conn.end()
    });
  });
});



router.patch("/product/patch", (req, res) => {
  const { name, pric, number } = req.body;
  app.locals.backname=name;
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("連接失敗！錯誤：" + err);
      res.status(500).json({ error: '數據庫連接失敗' });
      return;
    }
    const query = 'UPDATE product SET pric=?,number=? WHERE name=?';
    const values = [pric, number, name];
    conn.query(query, values, (err, result) => {
      if (err) {
        console.error('插入數據時發生錯誤：', err);
        res.status(500).json({ error: '插入數據時發生錯誤' });
        return;
      }
      res.send("success");
      conn.end();
    });
  });
});

router.post('/upload', upload.single('image'), (req, res) => {
  const name=app.locals.backname;
  const picturename=req.file.filename;
  const picture=(path.join('/img/'+picturename));
  pool.getConnection((err, conn) => {
    if (err) {
      console.log("連接失敗！錯誤：" + err);
      res.status(500).json({ error: '數據庫連接失敗' });
      return;
    }
    const query = 'UPDATE product SET picture=? WHERE name=?';
    const values = [picture, name];
    conn.query(query, values, (err, result) => {
      if (err) {
        console.error('插入數據時發生錯誤：', err);
        res.status(500).json({ error: '插入數據時發生錯誤' });
        return;
      }
      res.redirect('/back.html');
      conn.end();
    });
  });
  
  
  
}); 


module.exports = router;
